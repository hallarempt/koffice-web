// Please add a license header here and change the copyright
// to your name.

#include <fooimport.h>
#include <koFilterChain.h>
#include <kgenericfactory.h>

typedef KGenericFactory<FooImport, KoFilter> FooImportFactory;
K_EXPORT_COMPONENT_FACTORY( libfooimport, FooImportFactory( "fooimport" ) );

FooImport::FooImport(KoFilter *, const char *, const QStringList&) : KoFilter()
{
}

FooImport::~FooImport()
{
}

KoFilter::ConversionStatus FooImport::convert(const QCString& from, const QCString& to)
{
    // check for proper conversion
    if ( to != "application/x-kword" || from != "text/x-foo" )
        return KoFilter::NotImplemented;

    // Do the conversion stuff here. For notes how to get the input/output
    // locations please refer to koffice/lib/kofficecore/koFilterChain.h

    return KoFilter::NotImplemented; // Change to KoFilter::OK if the conversion
                                     // was successfull
}

#include <fooimport.moc>
