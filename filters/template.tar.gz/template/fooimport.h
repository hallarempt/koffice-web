// Please add a license header here and change the copyright
// to your name.

#ifndef __FOOIMPORT_H__
#define __FOOIMPORT_H__

#include <koFilter.h>

class FooImport : public KoFilter
{
    Q_OBJECT

public:
    FooImport(KoFilter *parent, const char *name, const QStringList&);
    virtual ~FooImport();

    virtual KoFilter::ConversionStatus convert(const QCString& from, const QCString& to);
};

#endif // __FOOIMPORT_H__
